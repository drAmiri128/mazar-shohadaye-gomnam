# سایت مزار شهدای گمنام

این پروژه یک سایت استاتیک آماده انتشار روی Cloudflare Pages است.

## ساختار
- `index.html` — کل سایت

## فعال کردن دانلود APK
وقتی APK آماده شد، می‌توان لینک فایل را در دکمه «دانلود APK» قرار داد.

برای مثال:
```html
<a class="btn btn-primary" href="LINK-APK" download>⬇️ دانلود APK</a>
```
